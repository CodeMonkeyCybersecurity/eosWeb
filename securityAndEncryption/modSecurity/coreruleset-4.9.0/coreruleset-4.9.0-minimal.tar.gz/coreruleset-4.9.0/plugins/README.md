This is the folder where you install CRS plugins.

See https://github.com/coreruleset/plugin-registry
for a list of registered official and 3rd party plugins.

Plugins are documented in the CRS INSTALL file and
in also with said plugin registry.
